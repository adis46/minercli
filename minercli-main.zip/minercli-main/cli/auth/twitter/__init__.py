from ._impl import set_active_account, get_active_account, remove_active_account
